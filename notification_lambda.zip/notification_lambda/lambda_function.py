import boto3
from data_service import get_latest_data
from string import Template

def lambda_handler(event, context):
    ses = boto3.client('ses', region_name='us-east-1')
    
    user_data = get_latest_data()
    
    with open("email_template.txt") as f:
        template = Template(f.read())
    
    message = template.substitute(user_data)

    response = ses.send_email(
        Source="admin@yourdomain.com",
        Destination={'ToAddresses': [user_data['email']]},
        Message={
            'Subject': {'Data': 'Your Study Reminder'},
            'Body': {'Text': {'Data': message}}
        }
    )

    return {"statusCode": 200, "body": "Email sent successfully"}
