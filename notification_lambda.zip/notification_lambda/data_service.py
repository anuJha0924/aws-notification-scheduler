def get_latest_data():
    return {
        "name": "Alice",
        "event": "Math Class",
        "time": "5:00 PM",
        "subject": "Mathematics",
        "score": 88,
        "email": "alice@example.com"
    }
