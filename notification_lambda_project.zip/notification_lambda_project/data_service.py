def get_latest_data():
    return {
        "name": "Anu",
        "event": "Coding Class",
        "time": "5:00 PM",
        "subject": "Python",
        "score": 88,
        "email": "anuJha2499@gmail.com"
    }
